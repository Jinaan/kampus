String API_LINK = "https://www.themealdb.com/api/json/v1/1/";
